package com.selenium.demoproj1.miniproject1.tests;

import com.selenium.demoproj1.miniproject1.base.BaseTest;
import com.selenium.demoproj1.miniproject1.pages.*;
import com.utility.CaptureScreenShot999;

import java.io.IOException;

import org.testng.annotations.Test;

public class NavigationTest extends BaseTest {

    @Test
    public void testNavigationAndForm() throws InterruptedException, IOException {
        driver.get("https://google.com");
        Thread.sleep(2000);

        GooglePage google = new GooglePage(driver);
        google.search("Orange HRM demo");
        Thread.sleep(3000);

        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().forward();
        Thread.sleep(2000);

        driver.get("https://www.orangehrm.com/");
        OrangeHRMHomePage home = new OrangeHRMHomePage(driver);
        home.clickContactSales();

        ContactSalesPage contactPage = new ContactSalesPage(driver);
        contactPage.fillForm("Vikram Rathode", "1234567890", "Fresher", "India", "11 - 50", "rathodeitsolutions.test@test.com");

        System.out.println("Please complete CAPTCHA manually...");
        Thread.sleep(20000);

        contactPage.submitForm();
        Thread.sleep(3000);

        CaptureScreenShot999.captureScreenShot(driver);

        contactPage.enterComment("Looking forward to hearing from you.");
        contactPage.submitForm();
        
        contactPage.goBack();

        System.out.println("Completed successfully");
    }
}
