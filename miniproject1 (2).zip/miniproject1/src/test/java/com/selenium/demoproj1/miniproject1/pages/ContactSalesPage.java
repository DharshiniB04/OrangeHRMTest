package com.selenium.demoproj1.miniproject1.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;

public class ContactSalesPage {
    WebDriver driver;

    @FindBy(name = "FullName")
    WebElement fullName;

    @FindBy(name = "Contact")
    WebElement contact;

    @FindBy(name = "JobTitle")
    WebElement jobTitle;

    @FindBy(name = "Country")
    WebElement countryDropdown;

    @FindBy(name = "NoOfEmployees")
    WebElement employeesDropdown;

    @FindBy(name = "Email")
    WebElement email;

    @FindBy(name = "Comment")
    WebElement comment;

    @FindBy(id = "Form_getForm_action_submitForm")
    WebElement submitButton;

    public ContactSalesPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillForm(String name, String phone, String title, String country, String employees, String mail) {
        fullName.sendKeys(name);
        contact.sendKeys(phone);
        jobTitle.sendKeys(title);
        new Select(countryDropdown).selectByVisibleText(country);
        new Select(employeesDropdown).selectByVisibleText(employees);
        email.sendKeys(mail);
    }

    public void submitForm() {
        submitButton.click();
    }

    public void enterComment(String msg) {
        comment.sendKeys(msg);
    }
    
    public void goBack() {
        driver.navigate().back();
    }
}
