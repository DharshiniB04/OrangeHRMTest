package com.selenium.demoproj1.miniproject1.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class GooglePage {
    WebDriver driver;

    @FindBy(name = "q")
    WebElement searchBox;

    public GooglePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void search(String query) {
        searchBox.sendKeys(query);
        searchBox.sendKeys(Keys.RETURN);
    }
}
