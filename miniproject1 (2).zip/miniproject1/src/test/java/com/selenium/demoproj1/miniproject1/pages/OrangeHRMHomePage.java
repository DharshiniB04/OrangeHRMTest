package com.selenium.demoproj1.miniproject1.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class OrangeHRMHomePage {
    WebDriver driver;

    @FindBy(linkText = "Contact Sales")
    WebElement contactSalesLink;

    public OrangeHRMHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickContactSales() {
        contactSalesLink.click();
    }
}
