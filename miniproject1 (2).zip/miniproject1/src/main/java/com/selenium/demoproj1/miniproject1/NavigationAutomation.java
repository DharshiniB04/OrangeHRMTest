package com.selenium.demoproj1.miniproject1;
import java.io.IOException;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import com.utility.CaptureScreenShot999;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NavigationAutomation {
    public static final String FileName = null;

	public static void main(String[] args) throws InterruptedException, IOException {
        
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Step 1: Navigate to Google
        driver.get("https://google.com");
        Thread.sleep(2000);

        // Step 2: Search for "Orange HRM demo"
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Orange HRM demo");
        searchBox.sendKeys(Keys.RETURN);
        Thread.sleep(3000);

        // Step 3: Back to Google
        driver.navigate().back();
        Thread.sleep(2000);

        // Step 4: Forward to search results
        driver.navigate().forward();
        Thread.sleep(2000);

        // Step 5: Navigate to OrangeHRM
        driver.get("https://www.orangehrm.com/");
  

        // Step 6: Click CONTACT SALES
        driver.findElement(By.linkText("Contact Sales")).click();

        // Step 7: Fill the form
        driver.findElement(By.name("FullName")).sendKeys("Vikram Rathode");
        driver.findElement(By.name("Contact")).sendKeys("1234567890");
        driver.findElement(By.name("JobTitle")).sendKeys("Fresher");

        Select country = new Select(driver.findElement(By.name("Country")));
        country.selectByVisibleText("India");

        Select employees = new Select(driver.findElement(By.name("NoOfEmployees")));
        employees.selectByVisibleText("11 - 50");

        driver.findElement(By.name("Email")).sendKeys("rathodeitsolutions.test@test.com");

        // CAPTCHA cannot be automated directly
        System.out.println("Please complete CAPTCHA manually...");

        Thread.sleep(20000); // Wait for manual CAPTCHA

        // Submit without message
        driver.findElement(By.xpath("//input[@id='Form_getForm_action_submitForm']")).click();
        Thread.sleep(3000);
        
        //captureScreenShot for the message occurred
        CaptureScreenShot999.captureScreenShot(driver);
        
        // Enter message and submit again
        driver.findElement(By.name("Comment")).sendKeys("Looking forward to hearing from you.");
        driver.findElement(By.xpath("//input[@id='Form_getForm_action_submitForm']")).click();
        
        //navigate to the back page
        driver.navigate().back();

        System.out.println("Completed successfully");

//        Close browser
//        driver.quit();
    }
}
