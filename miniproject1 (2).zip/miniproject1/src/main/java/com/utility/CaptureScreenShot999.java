package com.utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CaptureScreenShot999 {

	  public static void captureScreenShot(WebDriver driver1) throws IOException {
	        File src = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
	        File dest = new File("src\\test\\resource\\orange_hrm_screenshots\\" + timestamp() + " " + "orange_hrm.png");
			FileUtils.copyFile(src, dest);
	    }

	    public static String timestamp() {
	        return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
	    }

}
